"""원본 자료를 보존하는 형상별 축 편집·원자 확정·Undo 서비스를 제공합니다."""
from __future__ import annotations
from dataclasses import replace
from typing import Any
from uuid import uuid4
import numpy as np
from .axis_settings_state import AxisEditSnapshot, AxisSettingsRuntimeState, AxisGizmoPivotSnapshot
from .constants import MARKER_GEOMETRY_SOURCE_MAIN, MARKER_GEOMETRY_SOURCE_COMPANION, MODEL_STATUS_REGISTERED, ROLE_REFERENCE, ROLE_MOVING
from .display_axes import DEFAULT_AXIS_PRESET, RC_OBJ_AXIS_PRESET, ModelDisplayTransform, create_model_display_transform
from .geometry_access import bounds_for_model

AXIS_SETTINGS_COMMAND = "EDIT_GEOMETRY_AXES"


def axis_transform_center(runtime: Any, model_id: str, *, companion: bool = False) -> np.ndarray:
    """대형 원본 배열을 순회하지 않고 저장된 바운딩 박스 중심을 반환합니다."""
    repository = runtime.model_repository
    model = repository.companion_mesh_for_model_id(model_id) if companion else repository.models[model_id]
    minimum, maximum = bounds_for_model(model)
    return minimum * 0.5 + maximum * 0.5


def centered_axis_transform(runtime: Any, model_id: str, transform: ModelDisplayTransform, *, companion: bool = False) -> ModelDisplayTransform:
    """원본 기준과 현재 위치를 유지하며 편집 중심을 해당 형상의 경계 중심으로 옮깁니다."""
    center = axis_transform_center(runtime, model_id, companion=companion)
    if transform.source_basis is not None:
        center = (np.asarray(transform.source_basis) @ np.append(center, 1.0))[:3]
    if tuple(center) == transform.pivot_source:
        return transform
    base = create_model_display_transform(transform.preset_id, transform.forward_axis, transform.up_axis)
    common = create_model_display_transform(
        transform.preset_id, transform.forward_axis, transform.up_axis,
        rotation_xyz_degrees=transform.rotation_xyz_degrees, translation_xyz=transform.translation_xyz,
        scale_xyz=transform.scale_xyz, pivot_source=transform.pivot_source,
    )
    translation = common.matrix_float64[:3, 3] - (base.matrix_float64[:3, :3] @ center - common.matrix_float64[:3, :3] @ center)
    return create_model_display_transform(
        transform.preset_id, transform.forward_axis, transform.up_axis,
        rotation_xyz_degrees=transform.rotation_xyz_degrees,
        translation_xyz=translation, scale_xyz=transform.scale_xyz, pivot_source=center,
        source_basis=transform.source_basis,
    )


def axis_transform_at_world_origin(runtime: Any, model_id: str, transform: ModelDisplayTransform, *, companion: bool = False) -> ModelDisplayTransform:
    """원본 기준과 정렬 변환을 유지하며 해당 형상의 경계 중심을 월드 원점으로 옮깁니다."""
    centered = centered_axis_transform(runtime, model_id, transform, companion=companion)
    alignment = runtime.model_repository.alignment_transform_for_model_id(model_id).matrix_float64
    target = np.linalg.solve(alignment, np.array((0.0, 0.0, 0.0, 1.0)))[:3]
    base = create_model_display_transform(centered.preset_id, centered.forward_axis, centered.up_axis)
    translation = target - base.matrix_float64[:3, :3] @ centered.pivot_source
    return create_model_display_transform(
        centered.preset_id, centered.forward_axis, centered.up_axis,
        rotation_xyz_degrees=centered.rotation_xyz_degrees,
        translation_xyz=translation, scale_xyz=centered.scale_xyz, pivot_source=centered.pivot_source,
        source_basis=centered.source_basis,
    )


class AxisSettingsError(RuntimeError):
    """유효하지 않은 축 설정이나 만료된 편집 기준을 나타냅니다."""


def axis_edit_active_block_reason(runtime: Any) -> str | None:
    """축 팝업의 임시 편집이 다른 계산·데이터 변경을 막는 이유를 반환합니다."""
    state = getattr(runtime, "axis_settings", None)
    return "열린 축 설정을 적용하거나 취소한 뒤 진행하십시오." if state is not None and state.is_active else None


def _other_operation_block_reason(runtime: Any) -> str | None:
    """확정 기준을 동시에 바꾸는 작업이 진행 중인지 확인합니다."""
    if not bool(getattr(runtime, "session_active", False)):
        return "활성 COLMAP Align 작업공간에서 축 설정을 열어 주세요."
    if bool(getattr(runtime, "import_in_progress", False)):
        return "모델 가져오기가 끝난 뒤 축을 설정하십시오."
    from .project_persistence.runtime import restore_input_block_reason

    restore_reason = restore_input_block_reason(runtime)
    if restore_reason is not None:
        return restore_reason
    if bool(getattr(getattr(runtime, "marker_selection", None), "has_draft", False)) or bool(getattr(runtime, "modal_active", False)):
        return "마커 입력을 확정하거나 취소한 뒤 축을 설정하십시오."
    if bool(getattr(getattr(runtime, "layer_transform", None), "is_active", False)):
        return "레이어 변환을 확정하거나 취소한 뒤 축을 설정하십시오."
    marker = getattr(runtime, "marker_alignment", None)
    icp = getattr(runtime, "icp_alignment", None)
    if bool(getattr(marker, "is_active", False)) or bool(getattr(icp, "is_running", False)) or bool(getattr(icp, "has_preview", False)):
        return "정렬 작업과 미리보기를 마친 뒤 축을 설정하십시오."
    for name in ("merge_export", "obj_export"):
        if bool(getattr(getattr(runtime, name, None), "is_running", False)):
            return "내보내기가 끝난 뒤 축을 설정하십시오."
    if bool(getattr(getattr(runtime, "undo_journal", None), "scope_active", False)):
        return "현재 편집을 확정하거나 취소한 뒤 축을 설정하십시오."
    catalog = getattr(runtime, "model_catalog", None)
    if catalog is not None and catalog.has_preview():
        return "정렬 미리보기를 마친 뒤 축을 설정하십시오."
    return None


def axis_edit_block_reason(runtime: Any, model_id: str | None = None) -> str | None:
    """새 축 편집의 세션·작업 잠금·대상 유효성을 한 경계에서 검사합니다."""
    reason = axis_edit_active_block_reason(runtime) or _other_operation_block_reason(runtime)
    if reason is not None:
        return reason
    if model_id is not None and (model_id not in runtime.model_repository.models or model_id not in runtime.model_catalog.models):
        return "축을 설정할 데이터 레이어를 찾을 수 없습니다."
    return None


def _snapshot(runtime: Any, model_id: str) -> AxisEditSnapshot:
    """현재 축·기즈모와 종속 정렬 감사 기록을 원본 복사 없이 묶습니다."""
    repository = runtime.model_repository
    record = runtime.model_catalog.models.get(model_id)
    if record is None or model_id not in repository.models:
        raise AxisSettingsError("축 설정 대상이 더 이상 존재하지 않습니다.")
    companion = repository.companion_mesh_for_model_id(model_id)
    related = tuple(
        (other_id, other.alignment_provenance)
        for other_id, other in sorted(runtime.model_catalog.models.items())
        if other_id != model_id and any(
            owner_id == model_id
            for owner_id, _source in getattr(other.alignment_provenance, "geometry_dependencies", ())
        )
    )
    return AxisEditSnapshot(model_id, repository.display_transform_for_model_id(model_id),
        repository.companion_display_transform_for_model_id(model_id) if companion is not None else None,
        record.alignment_provenance, related, _gizmo_snapshot(runtime))


def _gizmo_snapshot(runtime: Any) -> AxisGizmoPivotSnapshot:
    """현재 사용자 피벗을 배열 비교가 필요 없는 불변 스냅샷으로 읽습니다."""
    pivot = runtime.layer_transform
    return AxisGizmoPivotSnapshot(pivot.custom_pivot_role, pivot.custom_pivot_model_ids,
        pivot.custom_pivot_source_model_id, tuple(float(value) for value in pivot.custom_pivot_source_position_float64))


def _restore_gizmo_snapshot(runtime: Any, snapshot: AxisGizmoPivotSnapshot | None) -> None:
    """기즈모 앵커만 복원하고 진행 상태·카메라·원본 배열은 유지합니다."""
    if snapshot is None:
        return
    pivot = runtime.layer_transform
    pivot.custom_pivot_role = snapshot.role
    pivot.custom_pivot_model_ids = snapshot.model_ids
    pivot.custom_pivot_source_model_id = snapshot.source_model_id
    pivot.custom_pivot_source_position_float64 = np.asarray(snapshot.source_position, dtype=np.float64).copy()


def _axis_gizmo_scope(runtime: Any, model_id: str) -> tuple[str, tuple[str, ...]]:
    """현재 역할의 선택 범위를 유지하고 미선택 팝업 대상은 단독으로 지정합니다."""
    from .alignment.layer_transform import selected_model_ids_for_role

    record = runtime.model_catalog.models[model_id]
    role = ROLE_REFERENCE if record.registration_status == MODEL_STATUS_REGISTERED else ROLE_MOVING
    selected = selected_model_ids_for_role(runtime.model_catalog, role)
    return role, selected if model_id in selected else (model_id,)


def _axis_gizmo_matrix(runtime: Any, state: AxisSettingsRuntimeState, model_id: str) -> np.ndarray:
    """편집 대상에는 임시 주 형상 축을 적용해 원본 피벗의 월드 행렬을 반환합니다."""
    repository = runtime.model_repository
    transform = state.main_transform if model_id == state.model_id else repository.display_transform_for_model_id(model_id)
    return repository.alignment_transform_for_model_id(model_id).matrix_float64 @ transform.matrix_float64


def _displayed_axis_state(state: AxisSettingsRuntimeState) -> AxisSettingsRuntimeState:
    """미리보기 선택에 따라 실제 표시 중인 축만 계산용 상태에 연결합니다."""
    return state if state.preview_enabled else replace(state,
        main_transform=state.baseline.main_transform, companion_transform=state.baseline.companion_transform)


def _axis_gizmo_world_position(runtime: Any, state: AxisSettingsRuntimeState) -> np.ndarray:
    """지정한 표시 축에서 사용자 피벗 또는 선택 원점 평균을 계산합니다."""
    role, model_ids = _axis_gizmo_scope(runtime, state.model_id)
    pivot = state.gizmo_pivot
    if pivot is not None and pivot.role == role and pivot.model_ids == model_ids and pivot.source_model_id in model_ids:
        return (_axis_gizmo_matrix(runtime, state, pivot.source_model_id) @ np.append(pivot.source_position, 1.0))[:3]
    return np.mean([_axis_gizmo_matrix(runtime, state, model_id)[:3, 3] for model_id in model_ids], axis=0)


def axis_gizmo_world_position(runtime: Any, token: str, *, displayed: bool = False) -> np.ndarray:
    """후보 또는 실제 표시 축을 선택해 현재 기즈모의 월드 위치를 반환합니다."""
    state = _validated_state(runtime, token)
    return _axis_gizmo_world_position(runtime, _displayed_axis_state(state) if displayed else state)


def _axis_gizmo_anchor(runtime: Any, state: AxisSettingsRuntimeState, world_position: np.ndarray) -> AxisGizmoPivotSnapshot:
    """월드 피벗을 대상 주 형상에 고정해 이후 이동에도 함께 따라가게 합니다."""
    source = np.linalg.solve(_axis_gizmo_matrix(runtime, state, state.model_id), np.append(world_position, 1.0))[:3]
    if not np.isfinite(source).all():
        raise AxisSettingsError("기즈모 중심을 유한한 원본 좌표로 변환할 수 없습니다.")
    role, model_ids = _axis_gizmo_scope(runtime, state.model_id)
    return AxisGizmoPivotSnapshot(role, model_ids, state.model_id, tuple(float(value) for value in source))


def center_axis_gizmo_on_bounds(runtime: Any, token: str) -> bool:
    """현재 표시의 경계 중심을 기즈모에 즉시 확정하고 미적용 축 입력은 유지합니다."""
    from .axis_edit_transform import dataset_world_center

    state = _validated_state(runtime, token)
    displayed = _displayed_axis_state(state)
    center = dataset_world_center(runtime, state.model_id, displayed.main_transform, displayed.companion_transform)
    candidate = replace(state, main_transform=state.baseline.main_transform,
        companion_transform=state.baseline.companion_transform, gizmo_pivot=_axis_gizmo_anchor(runtime, displayed, center))
    after = _commit_axis_candidate(runtime, candidate, "기즈모를 바운딩 박스 중심으로")
    changed = after is not state.baseline
    state.baseline, state.gizmo_pivot = after, after.gizmo_pivot
    return changed


def _translated_axis_transform(transform: ModelDisplayTransform | None, delta: np.ndarray) -> ModelDisplayTransform | None:
    """원본 축·회전·배율·보정은 유지하고 정렬 전 평행이동만 더합니다."""
    if transform is None or not np.any(delta):
        return transform
    return create_model_display_transform(transform.preset_id, transform.forward_axis, transform.up_axis,
        rotation_xyz_degrees=transform.rotation_xyz_degrees, scale_xyz=transform.scale_xyz,
        pivot_source=transform.pivot_source, source_basis=transform.source_basis,
        translation_xyz=np.asarray(transform.translation_xyz) + delta)


def move_axis_geometry_gizmo_to_origin(runtime: Any, token: str) -> bool:
    """현재 표시 기즈모 기준의 이동만 즉시 확정하고 미적용 축에도 같은 이동을 반영합니다."""
    state = _validated_state(runtime, token)
    displayed = _displayed_axis_state(state)
    world = _axis_gizmo_world_position(runtime, displayed)
    pivot = _axis_gizmo_anchor(runtime, displayed, world)
    alignment = runtime.model_repository.alignment_transform_for_model_id(state.model_id).matrix_float64
    delta = np.linalg.solve(alignment[:3, :3], -world)

    main = _translated_axis_transform(state.main_transform, delta)
    companion = _translated_axis_transform(state.companion_transform, delta)
    candidate = replace(state,
        main_transform=_translated_axis_transform(state.baseline.main_transform, delta),
        companion_transform=_translated_axis_transform(state.baseline.companion_transform, delta), gizmo_pivot=pivot)
    after = _commit_axis_candidate(runtime, candidate, "기즈모 기준 물체 원점 이동")
    changed = after is not state.baseline
    state.main_transform, state.companion_transform = main, companion
    state.baseline, state.gizmo_pivot = after, after.gizmo_pivot
    return changed


def _geometry_identity(runtime: Any, model_id: str) -> tuple:
    """같은 ID의 데이터가 교체된 경우도 감지할 메모리·형상 revision 기준을 만듭니다."""
    repository = runtime.model_repository
    model = repository.models.get(model_id)
    companion = repository.companion_mesh_for_model_id(model_id)
    return (id(model), getattr(model, "geometry_revision", None), id(companion), getattr(companion, "geometry_revision", None))


def begin_axis_edit(runtime: Any, model_id: str, *, window_pointer: int = 0, workspace_pointer: int = 0) -> str:
    """한 데이터셋의 축·기즈모 기준을 고정하고 확정 상태와 분리된 편집 토큰을 발급합니다."""
    model_id = str(model_id).strip()
    reason = axis_edit_block_reason(runtime, model_id)
    if reason is not None:
        raise AxisSettingsError(reason)
    state = runtime.axis_settings
    baseline = _snapshot(runtime, model_id)
    state.token = uuid4().hex
    state.model_id = model_id
    state.main_transform = baseline.main_transform
    state.companion_transform = baseline.companion_transform
    state.baseline = baseline
    state.gizmo_pivot = baseline.gizmo_pivot
    state.baseline_alignment_fingerprint = runtime.model_repository.alignment_transform_for_model_id(model_id).fingerprint
    state.geometry_identity = _geometry_identity(runtime, model_id)
    state.preview_enabled = True
    state.window_pointer = int(window_pointer)
    state.workspace_pointer = int(workspace_pointer)
    runtime.clear_data_layer_click()
    return state.token


def _validated_state(runtime: Any, token: str) -> AxisSettingsRuntimeState:
    """형상·축·기즈모·연결된 품질 기록이 바뀐 편집 토큰의 확정을 차단합니다."""
    state = runtime.axis_settings
    if not state.is_active or state.token != str(token) or state.baseline is None:
        raise AxisSettingsError("축 설정 창이 만료되었습니다. 다시 열어 주세요.")
    current = _snapshot(runtime, state.model_id)
    baseline = state.baseline
    if (_geometry_identity(runtime, state.model_id) != state.geometry_identity
        or current.provenance != baseline.provenance
        or current.related_provenances != baseline.related_provenances
        or current.gizmo_pivot != baseline.gizmo_pivot
        or current.main_transform.fingerprint != baseline.main_transform.fingerprint
        or (current.companion_transform.fingerprint if current.companion_transform else None) != (baseline.companion_transform.fingerprint if baseline.companion_transform else None)
        or runtime.model_repository.alignment_transform_for_model_id(state.model_id).fingerprint != state.baseline_alignment_fingerprint):
        raise AxisSettingsError("편집 중 원본 형상·축·기즈모 또는 정렬 기준이 바뀌었습니다. 취소 후 다시 열어 주세요.")
    return state


def update_axis_edit(runtime: Any, token: str, *, main_transform: ModelDisplayTransform,
                     companion_transform: ModelDisplayTransform | None = None, preview_enabled: bool = True) -> None:
    """유효한 두 형상 축을 임시 미리보기에만 원자적으로 반영합니다."""
    state = _validated_state(runtime, token)
    if not isinstance(main_transform, ModelDisplayTransform):
        raise AxisSettingsError("주 모델의 축 설정이 올바르지 않습니다.")
    if (state.baseline.companion_transform is None) != (companion_transform is None):
        raise AxisSettingsError("연결 메시 유무와 축 설정이 일치하지 않습니다.")
    if companion_transform is not None and not isinstance(companion_transform, ModelDisplayTransform):
        raise AxisSettingsError("연결 메시의 축 설정이 올바르지 않습니다.")
    state.main_transform = main_transform
    state.companion_transform = companion_transform
    state.preview_enabled = bool(preview_enabled)


def effective_axis_transform(runtime: Any, model_id: str, *, companion: bool = False) -> ModelDisplayTransform:
    """해당 형상의 확정 축 또는 같은 대상의 활성 임시 미리보기 축을 반환합니다."""
    repository = runtime.model_repository
    committed = (repository.companion_display_transform_for_model_id(model_id) if companion else repository.display_transform_for_model_id(model_id))
    state = getattr(runtime, "axis_settings", None)
    if state is not None and state.is_active and state.preview_enabled and state.model_id == model_id:
        candidate = state.companion_transform if companion else state.main_transform
        if isinstance(candidate, ModelDisplayTransform):
            return candidate
    return committed


def rc_axis_pair_for_model(runtime: Any, model_id: str) -> tuple[ModelDisplayTransform, ModelDisplayTransform | None]:
    """모델 종류와 연결 유무에 맞는 명시적 RC 초기 축 조합을 만듭니다."""
    repository = runtime.model_repository
    main_is_mesh = repository.geometry_kind_for_model_id(model_id) == "TRIANGLE_MESH"
    main = create_model_display_transform(RC_OBJ_AXIS_PRESET, "Y", "Z") if main_is_mesh else create_model_display_transform(DEFAULT_AXIS_PRESET, "Z", "-Y")
    companion = create_model_display_transform(RC_OBJ_AXIS_PRESET, "Y", "Z") if repository.companion_mesh_for_model_id(model_id) is not None else None
    return main, companion


def _apply_snapshot_atomic(runtime: Any, snapshot: AxisEditSnapshot) -> None:
    """형상별 축·기즈모와 종속 모델의 감사 기록을 원자적으로 갱신·복원합니다."""
    repository = runtime.model_repository
    before = _snapshot(runtime, snapshot.model_id)
    if (before.companion_transform is None) != (snapshot.companion_transform is None):
        raise AxisSettingsError("축 스냅샷의 연결 메시 구성이 현재 모델과 다릅니다.")
    record_ids = (snapshot.model_id, *(model_id for model_id, _record in snapshot.related_provenances))
    if any(model_id not in runtime.model_catalog.models for model_id in record_ids):
        raise AxisSettingsError("축 설정과 연결된 정렬 모델이 더 이상 존재하지 않습니다.")
    records_before = {model_id: runtime.model_catalog.models[model_id] for model_id in record_ids}
    try:
        if before.main_transform.fingerprint != snapshot.main_transform.fingerprint:
            repository.set_display_transform(snapshot.model_id, snapshot.main_transform)
        if snapshot.companion_transform is not None and before.companion_transform.fingerprint != snapshot.companion_transform.fingerprint:
            repository.set_companion_display_transform(snapshot.model_id, snapshot.companion_transform)
        runtime.model_catalog.set_alignment_provenance(snapshot.model_id, snapshot.provenance)
        for model_id, provenance in snapshot.related_provenances:
            runtime.model_catalog.set_alignment_provenance(model_id, provenance)
        _restore_gizmo_snapshot(runtime, snapshot.gizmo_pivot)
    except Exception:
        repository.display_transforms[snapshot.model_id] = before.main_transform
        if before.companion_transform is not None:
            repository.companion_display_transforms[snapshot.model_id] = before.companion_transform
        runtime.model_catalog.models.update(records_before)
        _restore_gizmo_snapshot(runtime, before.gizmo_pivot)
        raise


def _marker_source_is_referenced(runtime: Any, model_id: str, geometry_source: str) -> bool:
    """현재 마커와 정밀 정렬의 승인 기록이 지정한 형상 축에 의존하는지 확인합니다."""
    for pair in runtime.marker_selection.completed_pairs:
        for point in (pair.reference, pair.moving):
            if point.model_id == model_id and getattr(point, "geometry_source", MARKER_GEOMETRY_SOURCE_MAIN) == geometry_source:
                return True
    dependency = (model_id, geometry_source)
    return any(
        dependency in getattr(record.alignment_provenance, "geometry_dependencies", ())
        for record in runtime.model_catalog.models.values()
    )


def _invalidate_axis_derivatives(runtime: Any, model_id: str, main_changed: bool, companion_changed: bool) -> None:
    """계산에 사용한 축이 바뀔 때만 원본 마커를 보존하고 이전 파생 결과를 비웁니다."""
    marker_axis_changed = companion_changed and _marker_source_is_referenced(
        runtime, model_id, MARKER_GEOMETRY_SOURCE_COMPANION,
    )
    if main_changed or marker_axis_changed:
        runtime.marker_alignment.clear(error_message="축 설정 변경으로 정렬 기준이 갱신되었습니다.")
        icp = runtime.icp_alignment
        if not icp.is_running and not icp.has_preview and icp.job_handle is None:
            icp.clear(error_message="축 설정 변경으로 정렬 기준이 갱신되었습니다.")


def _invalidated_axis_provenance(runtime: Any, model_id: str, provenance: Any, fingerprint: str):
    """공통 정렬은 유지하면서 더 이상 유효하지 않은 정렬 품질 수치를 제거합니다."""
    from .alignment.types import AlignmentProvenanceRecord

    return AlignmentProvenanceRecord(
        model_id=model_id,
        method="MANUAL",
        input_fingerprint=fingerprint,
        result_fingerprint=runtime.model_repository.alignment_transform_for_model_id(model_id).fingerprint,
        marker_geometry_dependencies=getattr(provenance, "marker_geometry_dependencies", ()),
        solver_geometry_dependencies=getattr(provenance, "solver_geometry_dependencies", ()),
    )


def _commit_axis_candidate(runtime: Any, state: AxisSettingsRuntimeState, action: str) -> AxisEditSnapshot:
    """독립된 후보를 하나의 원자적 이력으로 확정하고 팝업의 수명은 변경하지 않습니다."""
    reason = _other_operation_block_reason(runtime)
    if reason is not None:
        raise AxisSettingsError(reason)
    before = state.baseline
    main_changed = before.main_transform.fingerprint != state.main_transform.fingerprint
    companion_changed = (before.companion_transform.fingerprint if before.companion_transform else None) != (state.companion_transform.fingerprint if state.companion_transform else None)
    if not main_changed and not companion_changed and before.gizmo_pivot == state.gizmo_pivot:
        return before
    changed_sources = {
        source for source, changed in (
            (MARKER_GEOMETRY_SOURCE_MAIN, main_changed),
            (MARKER_GEOMETRY_SOURCE_COMPANION, companion_changed),
        ) if changed
    }
    changed_dependencies = {(state.model_id, source) for source in changed_sources}
    fingerprint = state.companion_transform.fingerprint if companion_changed and not main_changed else state.main_transform.fingerprint
    provenance = before.provenance
    if main_changed or changed_dependencies.intersection(getattr(provenance, "geometry_dependencies", ())):
        provenance = _invalidated_axis_provenance(runtime, state.model_id, provenance, fingerprint)
    related = tuple(
        (
            model_id,
            _invalidated_axis_provenance(runtime, model_id, record, fingerprint)
            if changed_dependencies.intersection(getattr(record, "geometry_dependencies", ()))
            else record,
        )
        for model_id, record in before.related_provenances
    )
    after = AxisEditSnapshot(state.model_id, state.main_transform, state.companion_transform, provenance, related, state.gizmo_pivot)
    _apply_snapshot_atomic(runtime, after)
    try:
        label = f"{runtime.model_catalog.models[state.model_id].display_name} {action}"
        if not runtime.undo_journal.record_committed(before, after, label, AXIS_SETTINGS_COMMAND):
            raise AxisSettingsError("축 설정 Undo 기록을 만들지 못했습니다.")
    except Exception:
        _apply_snapshot_atomic(runtime, before)
        raise
    _invalidate_axis_derivatives(runtime, state.model_id, main_changed, companion_changed)
    return after


def commit_axis_edit(runtime: Any, token: str) -> bool:
    """즉시 실행 이후 남은 축 입력만 단일 이력으로 확정하고 팝업을 종료합니다."""
    state = _validated_state(runtime, token)
    after = _commit_axis_candidate(runtime, state, "축 설정")
    changed = after is not state.baseline
    state.clear()
    return changed


def cancel_axis_edit(runtime: Any, token: str | None = None) -> bool:
    """현재 팝업의 임시 축·기즈모만 폐기하고 확정 상태와 이력은 유지합니다."""
    state = getattr(runtime, "axis_settings", None)
    if state is None or not state.is_active or (token is not None and str(token) != state.token):
        return False
    state.clear()
    return True


def restore_axis_edit_snapshot(runtime: Any, snapshot: AxisEditSnapshot) -> None:
    """세션 되돌리기·다시 실행에서 형상별 축·기즈모·종속 품질을 함께 복원합니다."""
    if not isinstance(snapshot, AxisEditSnapshot):
        raise AxisSettingsError("복원할 축 설정 스냅샷이 올바르지 않습니다.")
    before = _snapshot(runtime, snapshot.model_id)
    _apply_snapshot_atomic(runtime, snapshot)
    _invalidate_axis_derivatives(
        runtime,
        snapshot.model_id,
        before.main_transform.fingerprint != snapshot.main_transform.fingerprint,
        (before.companion_transform.fingerprint if before.companion_transform else None)
        != (snapshot.companion_transform.fingerprint if snapshot.companion_transform else None),
    )
